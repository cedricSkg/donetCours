﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TP3_
{
    /// <summary>
    /// Logique d'interaction pour Diaporama.xaml
    /// </summary>
    public partial class Diaporama : Window
    {
        public List<String> sDiapo = new List<String>();
        public Diaporama()
        {
            InitializeComponent();
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            if (sDiapo.Count > 0)
            {
                // Affichez la première image ou effectuez d'autres actions nécessaires
                ImageSourceConverter s = new ImageSourceConverter();
                Image1.Source = (ImageSource)s.ConvertFromString(sDiapo[0]);
            }
        }

    }
}
